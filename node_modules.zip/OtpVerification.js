const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: "armdisarmdatabase.ct0mqmao4tk1.ap-south-1.rds.amazonaws.com",
    user: "admin",
    password: "support8888",
    database: "ArmDisarmDB",
    port: "3306"
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL database!');

    // Example query
    connection.query('SELECT * FROM your_table_name', (error, results) => {
        if (error) {
            console.error('Error executing query:', error);
        } else {
            console.log('Query results:', results);
        }
        
        // Close the connection after the query
        connection.end((endErr) => {
            if (endErr) {
                console.error('Error closing the connection:', endErr);
            } else {
                console.log('Connection closed.');
            }
        });
    });
});
